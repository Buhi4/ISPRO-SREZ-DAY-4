﻿using Library.Class;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Library
{
    /// <summary>
    /// Логика взаимодействия для MainMenu.xaml
    /// </summary>
    public partial class MainMenu : Window
    {
        
        
        string token;
        List<Reader> readers = new List<Reader>();
        
        public MainMenu(string token)
        {
            InitializeComponent();
            this.token = token;

            Data();
        }
        public async void Data(string search = "")
        {
            try
            {
                using (HttpClient httpClient = new HttpClient { BaseAddress = new Uri(Properties.Settings.Default.BaseAdress) })
                {

                    var reader = httpClient.GetStringAsync($"/GetReaders?token={token}");
                    readers = JsonSerializer.Deserialize<List<Reader>>(reader.Result);
                    if (!string.IsNullOrWhiteSpace(search))
                    {
                        readers = readers.Where(x => x.fullName.ToLower().Contains(search.ToLower())).ToList();

                        if (readers.Count() == 0)
                        {
                            MessageBox.Show("Результаты не найдены", "Внимание", MessageBoxButton.OK);
                        }
                    }

                    LvReader.ItemsSource = readers;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Ошибка", "Внимание", MessageBoxButton.OK);
            }

        }

        

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Вы точно хотите выйти?",
                    "Save file",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                MainWindow work = new MainWindow();
                work.Show();
                this.Close();
            }
        }

        private void tbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            Data(tbSearch.Text);
        }
    }
}
